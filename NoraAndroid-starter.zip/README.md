
# Nora Android — starter 0.1.0

Nora is a portable Android personal-assistant project. The first starter build includes:
- A native Android screen
- Four selectable speech-style presets
- Android TextToSpeech preview
- Speech input through the Android speech recognizer
- Export/import of basic settings as `nora-backup.json`
- GitHub Actions workflow to build a debug APK

## Build an APK with GitHub Actions
1. Create a GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Open **Actions** and run **Build Nora Android APK** (or push to `main`).
4. Open the completed workflow run and download the `Nora-debug-apk` artifact.

## Notes
- This is a starter foundation, not the finished AI agent.
- Speech recognition availability and Uzbek language support depend on installed Android speech services.
- TTS voice quality and Uzbek voice availability depend on the device's installed engines/voices.
- Always-on wake-word listening, AI backend, account sync, GitHub/Telegram integrations and MT5 automation are not implemented yet.
- Settings backup currently includes the selected voice style only. Never put API keys or passwords in a plain backup file.
- The app is designed with `minSdk 26` and `targetSdk 35` and should be tested on the target device.

