package uz.nora.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var voiceSpinner: Spinner
    private lateinit var notes: EditText
    private var ttsReady = false
    private val prefs by lazy { getSharedPreferences("nora_settings", MODE_PRIVATE) }
    private val voices = listOf("Soft", "Professional", "Young", "Cinematic")
    private val testPhrase = "Salom! Men Nora. Bugun sizga qanday yordam bera olaman?"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF5F3FA.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 24)
        }
        val title = TextView(this).apply {
            text = "NORA"
            textSize = 32f
            setTextColor(0xFF34245C.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Shaxsiy AI yordamching"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFF625A70.toInt())
        }
        status = TextView(this).apply {
            text = "Tayyorlanmoqda…"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF625A70.toInt())
            setPadding(0, 18, 0, 18)
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(status)

        content.addView(section("Ovoz uslubi"))
        voiceSpinner = Spinner(this)
        voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, voices)
        val savedVoice = prefs.getString("voice_style", "Soft") ?: "Soft"
        voiceSpinner.setSelection(voices.indexOf(savedVoice).coerceAtLeast(0))
        voiceSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                prefs.edit().putString("voice_style", voices[position]).apply()
                applyVoiceStyle()
            }
        }
        content.addView(voiceSpinner)
        content.addView(actionButton("Ovozni tinglash") {
            if (ttsReady) {
                applyVoiceStyle()
                tts.speak(testPhrase, TextToSpeech.QUEUE_FLUSH, null, "nora_preview")
            } else status.text = "Ovoz tizimi hali tayyor emas."
        })

        content.addView(section("Nora bilan gaplashish"))
        content.addView(actionButton("Mikrofon orqali gapirish") { startSpeechInput() })
        notes = EditText(this).apply {
            hint = "Hozircha buyruq yoki eslatmangizni yozing…"
            minLines = 2
            textSize = 15f
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        content.addView(notes, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(actionButton("Buyruqni Nora'ga yuborish") {
            val command = notes.text.toString().trim()
            status.text = if (command.isEmpty()) "Avval buyruq yozing yoki mikrofonni bosing."
            else "Buyruq qabul qilindi: $command\nKeyingi bosqichda AI agentga ulanadi."
        })

        content.addView(section("Ma'lumotlarni ko‘chirish"))
        content.addView(TextView(this).apply {
            text = "Sozlamalarni zaxiralab, boshqa Android telefonda tiklash mumkin. Hozircha bu versiya faqat ovoz uslubi va Nora haqidagi lokal sozlamalarni saqlaydi."
            textSize = 13f
            setTextColor(0xFF625A70.toInt())
        })
        content.addView(actionButton("Zaxira faylini yaratish") { exportBackup() })
        content.addView(actionButton("Zaxira faylini tiklash") { importBackup() })

        content.addView(section("Keyingi bosqichlar"))
        content.addView(TextView(this).apply {
            text = "• O‘zbekcha AI suhbat\n• Nora uyg‘otish so‘zi\n• Kundalik reja va eslatmalar\n• GitHub va Telegram agentlari\n• Forex V6 va MT5 demo moduli\n\nEslatma: ekran o‘chiq holatda doimiy tinglash va boshqa ilovalarda amallar bajarish uchun qo‘shimcha Android ruxsatlari hamda xavfsizlik nazorati kerak."
            textSize = 14f
            setTextColor(0xFF494253.toInt())
            setPadding(0, 4, 0, 20)
        })

        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 18f
        setTextColor(0xFF34245C.toInt())
        setPadding(0, 24, 0, 8)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = 8
        layoutParams = lp
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts.setLanguage(Locale("uz", "UZ"))
            status.text = if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                "TTS tayyor. Qurilmada o‘zbekcha ovoz bo‘lmasa, Android sozlamalaridan ovoz paketini o‘rnating."
            else "Nora tayyor. Ovoz sifati telefondagi TTS ovozlariga bog‘liq."
            applyVoiceStyle()
        } else status.text = "Matnni ovozga aylantirish tizimi ishga tushmadi."
    }

    private fun applyVoiceStyle() {
        if (!ttsReady) return
        when (voices.getOrNull(voiceSpinner.selectedItemPosition) ?: "Soft") {
            "Soft" -> { tts.setSpeechRate(0.88f); tts.setPitch(1.08f) }
            "Professional" -> { tts.setSpeechRate(0.96f); tts.setPitch(0.96f) }
            "Young" -> { tts.setSpeechRate(1.08f); tts.setPitch(1.16f) }
            "Cinematic" -> { tts.setSpeechRate(0.82f); tts.setPitch(0.90f) }
        }
    }

    private fun startSpeechInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Nora'ga gapiring")
        }
        try { startActivityForResult(intent, 101) }
        catch (_: Exception) { status.text = "Bu telefonda nutqni aniqlash xizmati topilmadi." }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) notes.setText(spoken)
        }
        if (requestCode == 202 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    val json = JSONObject(contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() })
                    prefs.edit().putString("voice_style", json.optString("voice_style", "Soft")).apply()
                    val selected = voices.indexOf(prefs.getString("voice_style", "Soft")).coerceAtLeast(0)
                    voiceSpinner.setSelection(selected)
                    status.text = "Nora sozlamalari tiklandi."
                } catch (_: Exception) { status.text = "Zaxira faylini o‘qib bo‘lmadi." }
            }
        }
    }

    private fun exportBackup() {
        val json = JSONObject().put("app", "Nora").put("backup_version", 1)
            .put("voice_style", prefs.getString("voice_style", "Soft"))
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "nora-backup.json")
        }
        pendingBackup = json.toString()
        startActivityForResult(intent, 201)
    }

    private fun importBackup() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        startActivityForResult(intent, 202)
    }

    private var pendingBackup: String? = null

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
